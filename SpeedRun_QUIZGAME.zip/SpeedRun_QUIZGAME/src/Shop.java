import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Shop {
    private final Map<String, Integer> itemPrices;

    public Shop() {
        itemPrices = new HashMap<>();
        itemPrices.put("Pencil", 5);
        itemPrices.put("Pen", 10);
        itemPrices.put("Ink", 15);
        itemPrices.put("Lunch Box", 20);
        itemPrices.put("Bottle", 25);
        itemPrices.put("Bike", 100);
        itemPrices.put("Car", 500);
        itemPrices.put("TV", 300);
        itemPrices.put("Cycle", 50);
    }
    public List<String> getItems() {
        return new ArrayList<>(itemPrices.keySet());
    }
    public boolean purchaseItem(Player player, String item) {
        Integer itemCost = itemPrices.get(item);
        if (itemCost != null) {
            if (player.getCoins() >= itemCost) {
                player.addCoins(-itemCost);
                System.out.println("Purchased: " + item + " for " + itemCost + " coins");
                System.out.println("Coins left: " + player.getCoins());
                return true;
            } else {
                System.out.println("Not enough coins to purchase: " + item);
                System.out.println("You need " + (itemCost - player.getCoins()) + " more coins.");
                return false;
            }
        } else {
            System.out.println("Item not found: " + item);
            return false; // Item not found
        }
    }

    public Map<String, Integer> getItemPrices() {
        return itemPrices;
    }
}
