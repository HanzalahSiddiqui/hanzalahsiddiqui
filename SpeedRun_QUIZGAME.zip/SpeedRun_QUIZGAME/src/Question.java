import java.util.ArrayList;
import java.util.List;

public class Question {
    private String questionText;
    private String[] options;
    private int correctOptionIndex;
    private int difficulty;

    public Question(String questionText, String[] options, int correctOptionIndex, int difficulty) {
        this.questionText = questionText;
        this.options = options;
        this.correctOptionIndex = correctOptionIndex;
        this.difficulty = difficulty;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public boolean isCorrect(int index) {
        return index == correctOptionIndex;
    }

    public static List<Question> generateSampleQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What is the capital of France?", new String[]{"Paris", "London", "Berlin", "Madrid"}, 0, 1));
        questions.add(new Question("What is 2+2?", new String[]{"3", "4", "5", "6"}, 1, 1));
        questions.add(new Question("What is the largest ocean on Earth?", new String[]{"Atlantic", "Indian", "Arctic", "Pacific"}, 3, 1));
        questions.add(new Question("Which element has the chemical symbol 'O'?", new String[]{"Gold", "Oxygen", "Iron", "Osmium"}, 1, 1));
        questions.add(new Question("What is the powerhouse of the cell?", new String[]{"Nucleus", "Ribosome", "Mitochondria", "Endoplasmic Reticulum"}, 2, 5));
        questions.add(new Question("What is the capital of Japan?", new String[]{"Beijing", "Seoul", "Tokyo", "Bangkok"}, 2, 5));
        questions.add(new Question("Which scientist proposed the laws of motion?", new String[]{"Albert Einstein", "Isaac Newton", "Nikola Tesla", "Marie Curie"}, 1, 5));
        questions.add(new Question("What is the distance between the Earth and the Sun?", new String[]{"93 million miles", "50 million miles", "120 million miles", "80 million miles"}, 0, 10));
        questions.add(new Question("What is the hardest natural substance on Earth?", new String[]{"Gold", "Iron", "Diamond", "Quartz"}, 2, 10));
        questions.add(new Question("Who painted the Mona Lisa?", new String[]{"Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Claude Monet"}, 2, 10));



        return questions;
    }
}
