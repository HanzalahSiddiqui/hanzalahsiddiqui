import javax.swing.*;
import java.util.List;

public class SpeedRun {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Player player = new Player("Player 1", 1000);
            Leaderboard leaderboard = new Leaderboard();
            Shop shop = new Shop();
            List<Question> questions = Question.generateSampleQuestions();
            GameWindow gameWindow = new GameWindow(player, leaderboard, shop, questions);
            gameWindow.setVisible(true);
        });
    }
}
