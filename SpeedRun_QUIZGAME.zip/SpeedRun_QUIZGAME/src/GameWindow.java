import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

public class GameWindow extends JFrame {
    private GameController gameController;
    private JPanel mainPanel;
    private JTextArea questionArea;
    private JButton[] optionButtons;
    private JLabel scoreLabel, coinLabel, timerLabel;
    private Timer timer;
    private int timeLeft;
    private Question currentQuestion;

    public GameWindow(Player player, Leaderboard leaderboard, Shop shop, List<Question> questions) {
        setTitle("SpeedRun");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        gameController = new GameController(player, leaderboard, shop, questions);

        initUI();
    }

    private void initUI() {
        mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("G:\\Downloads1\\Java Project\\SpeedRun\\space-bac.jpg");
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };
        add(mainPanel);


        JPanel topPanel = new JPanel(new GridLayout(1, 3));
        topPanel.setOpaque(false);
        scoreLabel = new JLabel("Score: " + gameController.getPlayer().getScore());
        coinLabel = new JLabel("Coins: " + gameController.getPlayer().getCoins());
        timerLabel = new JLabel("Time: 0");
        scoreLabel.setForeground(Color.BLACK);
        coinLabel.setForeground(Color.BLACK);
        timerLabel.setForeground(Color.BLACK);
        topPanel.add(scoreLabel);
        topPanel.add(coinLabel);
        topPanel.add(timerLabel);

        mainPanel.add(topPanel, BorderLayout.NORTH);


        questionArea = new JTextArea();
        questionArea.setLineWrap(true);
        questionArea.setWrapStyleWord(true);
        questionArea.setEditable(false);
        questionArea.setOpaque(false);
        questionArea.setForeground(Color.BLACK);
        mainPanel.add(new JScrollPane(questionArea), BorderLayout.CENTER);


        JPanel optionsPanel = new JPanel(new GridLayout(2, 2));
        optionsPanel.setOpaque(false);
        optionButtons = new JButton[4];
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JButton();
            optionButtons[i].addActionListener(new OptionButtonListener(gameController.getPlayer()));
            optionButtons[i].setOpaque(false);
            optionButtons[i].setContentAreaFilled(false);
            optionButtons[i].setBorderPainted(false);
            optionButtons[i].setForeground(Color.BLACK);
            optionsPanel.add(optionButtons[i]);
        }
        mainPanel.add(optionsPanel, BorderLayout.SOUTH);

        startGame();
    }

    private void startGame() {
        nextQuestion();
    }

    private void nextQuestion() {
        currentQuestion = gameController.getNextQuestion();
        if (currentQuestion == null) {
            showGameOver();
            return;
        }

        questionArea.setText(currentQuestion.getQuestionText());
        String[] options = currentQuestion.getOptions();
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(options[i]);
        }
        timeLeft = 60; // 60 seconds for each question
        timerLabel.setText("Time: " + timeLeft);

        if (timer != null) {
            timer.stop();
        }
        timer = new Timer(1000, new TimerListener());
        timer.start();
    }

    private void showGameOver() {
        timer.stop();
        gameController.handleGameOver();
        int choice = JOptionPane.showOptionDialog(this, "Game Over! Your score: " + gameController.getPlayer().getScore() + "\nWhat would you like to do?", "Game Over",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, new String[]{"View Leaderboard", "Visit Shop"}, "View Leaderboard");

        if (choice == 0) {
            displayLeaderboard();
        } else if (choice == 1) {
            visitShop();
        }
    }

    private void displayLeaderboard() {
        StringBuilder leaderboardText = new StringBuilder("Leaderboard:\n");
        List<Player> topPlayers = gameController.getTopPlayers();
        for (Player p : topPlayers) {
            leaderboardText.append(p.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(this, leaderboardText.toString());
    }

    private void visitShop() {
        Map<String, Integer> itemPrices = gameController.getShop().getItemPrices();


        StringBuilder shopItemsText = new StringBuilder("Shop Items:\n");
        int index = 1;
        for (Map.Entry<String, Integer> entry : itemPrices.entrySet()) {
            shopItemsText.append(index++).append(". ").append(entry.getKey()).append(" - ").append(entry.getValue()).append(" coins\n");
        }

        String selectedItem = JOptionPane.showInputDialog(this, shopItemsText.toString() + "Enter the item number to purchase:");
        if (selectedItem != null && !selectedItem.isEmpty()) {
            try {
                int itemIndex = Integer.parseInt(selectedItem.trim()) - 1;
                List<String> items = gameController.getShopItems();
                if (itemIndex >= 0 && itemIndex < items.size()) {
                    String selectedItemName = items.get(itemIndex);
                    int itemCost = itemPrices.get(selectedItemName);
                    int playerCoins = gameController.getPlayerCoins();
                    if (playerCoins >= itemCost) {
                        boolean success = gameController.purchaseItem(selectedItemName);
                        if (success) {
                            coinLabel.setText("Coins: " + gameController.getPlayerCoins());
                            JOptionPane.showMessageDialog(this, "Purchase successful!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Purchase failed!");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Not enough coins!");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid item number!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "No item selected!");
        }
    }

    private class OptionButtonListener implements ActionListener {
        private Player player;

        public OptionButtonListener(Player player) {
            this.player = player;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JButton source = (JButton) e.getSource();
            String selectedOption = source.getText();
            int selectedIndex = -1;
            for (int i = 0; i < 4; i++) {
                if (optionButtons[i].getText().equals(selectedOption)) {
                    selectedIndex = i;
                    break;
                }
            }

            if (currentQuestion != null && currentQuestion.isCorrect(selectedIndex)) {
                player.addScore(10 * currentQuestion.getDifficulty());
                player.addCoins(currentQuestion.getDifficulty());
            }

            scoreLabel.setText("Score: " + player.getScore());
            coinLabel.setText("Coins: " + player.getCoins());
            nextQuestion();
        }
    }

    private class TimerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            timeLeft--;
            if (timeLeft <= 0) {
                timer.stop();
                nextQuestion();
            }
            timerLabel.setText("Time: " + timeLeft);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Player player = new Player("Player 1", 1000);
            Leaderboard leaderboard = new Leaderboard();
            Shop shop = new Shop();
            List<Question> questions = Question.generateSampleQuestions();
            GameWindow gameWindow = new GameWindow(player, leaderboard, shop, questions);
            gameWindow.setVisible(true);
        });
    }
}