import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Leaderboard {
    private List<Player> players;

    public Leaderboard() {
        this.players = new ArrayList<>();
        // Adding predefined players
        players.add(new Player("Player 1", 1000)); // Assuming initial score for Player 1 is 1000
        players.add(new Player("Player 2", 800));  // Assuming initial score for Player 2 is 800
        players.add(new Player("Player 2", 800));  // Assuming initial score for Player 2 is 800
        players.add(new Player("Player 2", 800));  // Assuming initial score for Player 2 is 800
        // Add more predefined players as needed
    }

    public List<Player> getTopPlayers() {
        Collections.sort(players, Comparator.comparingInt(Player::getScore).reversed());
        int topCount = Math.min(players.size(), 10);
        return players.subList(0, topCount);
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void display() {
        System.out.println("Leaderboard:");
        for (int i = 0; i < players.size(); i++) {
            System.out.println((i + 1) + ". " + players.get(i).getName() + ": " + players.get(i).getScore());
        }
    }
}
