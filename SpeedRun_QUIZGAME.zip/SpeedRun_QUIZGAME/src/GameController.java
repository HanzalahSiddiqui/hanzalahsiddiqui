import java.util.List;
import java.util.Map;

public class GameController {
    private Player player;
    private Leaderboard leaderboard;
    private Shop shop;
    private List<Question> questions;
    private int currentQuestionIndex;

    public GameController(Player player, Leaderboard leaderboard, Shop shop, List<Question> questions) {
        this.player = player;
        this.leaderboard = leaderboard;
        this.shop = shop;
        this.questions = questions;
        this.currentQuestionIndex = 0;
    }
    public Shop getShop() {
        return shop;
    }
    public List<String> getShopItems() {
        return shop.getItems();
    }

    public int getPlayerCoins() {
        return player.getCoins();
    }

    public List<Player> getTopPlayers() {
        return leaderboard.getTopPlayers();
    }

    public Player getPlayer() {
        return player;
    }

    public Question getNextQuestion() {
        if (currentQuestionIndex < questions.size()) {
            return questions.get(currentQuestionIndex++);
        } else {
            return null;
        }
    }

    public boolean purchaseItem(String itemName) {
        Map<String, Integer> itemPrices = shop.getItemPrices();
        if (itemPrices.containsKey(itemName)) {
            int itemCost = itemPrices.get(itemName);
            return shop.purchaseItem(player, itemName);
        } else {
            System.out.println("Item not found: " + itemName);
            return false;
        }
    }

    public void handleGameOver() {

        System.out.println("Game Over! Player Score: " + player.getScore());
        leaderboard.addPlayer(player);
        leaderboard.display();
    }
}
