public class Player implements Comparable<Player> {
    private String name;
    private int score;
    private int coins;

    public Player(String name, int i) {
        this.name = name;
        this.score = 0;
        this.coins = 0;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public int getCoins() {
        return coins;
    }

    public void addScore(int points) {
        score += points;
    }

    public void addCoins(int amount) {
        coins += amount;
    }

    @Override
    public int compareTo(Player other) {
        return Integer.compare(other.score, this.score);
    }

    @Override
    public String toString() {
        return name + " - Score: " + score + ", Coins: " + coins;
    }
}
